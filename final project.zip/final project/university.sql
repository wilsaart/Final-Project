-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 16, 2022 at 08:07 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university`
--

-- --------------------------------------------------------

--
-- Table structure for table `courseadd`
--

CREATE TABLE `courseadd` (
  `Course ID` int(50) NOT NULL,
  `Course Name` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Professor` varchar(50) NOT NULL,
  `Credits` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courseadd`
--

INSERT INTO `courseadd` (`Course ID`, `Course Name`, `Department`, `Professor`, `Credits`) VALUES
(111, 'Stats', 'Math', 'John Smith', 4),
(45, 'Database Systems', 'Computer Science', 'Frank', 4),
(122, 'American Lit', 'English', 'Robin', 3),
(334, 'French', 'Foreign Language', 'Madame', 3),
(335, 'Spanish', 'Foreign Language', 'Senior', 3),
(336, 'German', 'Foreign Language', 'Steve', 3),
(36778, 'Intro to Buisness', 'Foreign Buisness', 'Joe', 4),
(8888, 'Painting', 'Art', 'Rachel', 3),
(9999, 'Trumpet I', 'Music', 'Greg', 3),
(1010, 'Trumpet II', 'Music', 'Greg', 3);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('admin', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `managedep`
--

CREATE TABLE `managedep` (
  `depID` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `funding` varchar(50) NOT NULL,
  `course_no` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `managedep`
--

INSERT INTO `managedep` (`depID`, `name`, `addr`, `funding`, `course_no`) VALUES
(3345, 'Science', '2 Beacon St', '333344$', 7),
(6615, 'Comp Sci', '21st Main St', '44554$', 17),
(112373, 'Buisness', '22st Main St', '335554$', 21),
(13349, 'Music', '1st Main St', '6664646$', 2),
(89711, 'Art', '2 Sunny Rd', '33747$', 6),
(991723, 'English', '5 Sunny Rd', '337457$', 3),
(12553, 'Psychology', '3 Beacon St', '6667767$', 9),
(12552, 'Math', '2 Beacon St', '6667990$', 23),
(7654321, 'Foreign Language', '21st Main St', '99888988$', 6),
(12332, 'Nursing', '5 Sunny Rd', '55588$', 31);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `gpa` decimal(3,2) NOT NULL,
  `major` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `gender`, `gpa`, `major`) VALUES
(1234, 'Robert', 'Male', '3.40', 'Art'),
(1233, 'Robert', 'Male', '3.40', 'Art'),
(2235, 'Robert', 'Male', '3.40', 'Art'),
(4443, 'Robert', 'Male', '3.40', 'Art'),
(1556, 'Robert', 'Male', '3.40', 'Art'),
(9873, 'Robert', 'Male', '3.40', 'Art'),
(7756, 'Robert', 'Male', '3.40', 'Art'),
(7777, 'Robert', 'Male', '3.40', 'Art'),
(8912, 'Queenie', 'Female', '2.90', 'Chemistry');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
